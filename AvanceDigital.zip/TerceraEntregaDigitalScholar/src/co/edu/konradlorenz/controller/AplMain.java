package co.edu.konradlorenz.controller;

public class AplMain {

    public static void main(String[] args) {
        Control joa = new Control();
       joa.run();
    }
    
}
