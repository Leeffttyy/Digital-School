package co.edu.konradlorenz.model;

public interface Registrable {
    
    public Object[] obtenerCampos();
}
