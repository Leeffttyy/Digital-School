package co.edu.konradlorenz.model;

public enum TipoUsuario {
    ESTUDIANTE, PROFESOR;
}
