
package co.edu.konradlorenz.model;

public class ExcepcionNombreVacio extends Exception {
    public ExcepcionNombreVacio(String mensaje) {
        super(mensaje);
    }
}
